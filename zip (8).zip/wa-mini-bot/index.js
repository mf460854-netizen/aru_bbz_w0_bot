import { startTelegram } from './src/telegram.js';
import { restoreAll } from './src/wa.js';
import { startWeb } from './src/web.js';

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e));

startWeb();
startTelegram();
restoreAll().catch((e) => console.error('[restore]', e));
