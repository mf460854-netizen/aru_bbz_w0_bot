import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { countSessions } from './wa.js';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const started = Date.now();
let indexHtml; // read once, cached in memory

function send(res, code, type, body) {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(body);
}

export function startWeb() {
  const server = http.createServer((req, res) => {
    try {
      const url = new URL(req.url, 'http://x');

      if (url.pathname === '/health') return send(res, 200, 'text/plain', 'ok');

      if (url.pathname === '/api/status') {
        return send(res, 200, 'application/json', JSON.stringify({
          botName: config.botName,
          ownerName: config.ownerName,
          newsletterLink: config.newsletterLink,
          telegramBotUsername: config.telegramBotUsername,
          sessions: countSessions(),
          uptimeSec: Math.floor((Date.now() - started) / 1000)
        }));
      }

      if (url.pathname === '/' || url.pathname === '/index.html') {
        if (!indexHtml) indexHtml = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
        return send(res, 200, 'text/html; charset=utf-8', indexHtml);
      }

      return send(res, 404, 'text/plain', 'Not found');
    } catch (e) {
      console.error('[web]', e.message);
      send(res, 500, 'text/plain', 'Server error');
    }
  });

  server.listen(config.port, () => console.log(`✅ Website: http://localhost:${config.port}`));
  return server;
}
