import 'dotenv/config';

const clean = (v) => String(v || '').trim().replace(/^['"]|['"]$/g, '');
const list = (v) => clean(v).split(',').map((s) => clean(s)).filter(Boolean);
const envPrefix = (process.env.PREFIX || '').trim();
const safePrefix = /^[!#$%&*+\-./:;<=>?@[\]^_{|}~]$/.test(envPrefix) ? envPrefix : '/';

export const config = {
  tgToken: clean(process.env.TELEGRAM_BOT_TOKEN),
  adminIds: list(process.env.ADMIN_IDS),
  allowedIds: list(process.env.ALLOWED_IDS),
  maxSessions: Number(process.env.MAX_SESSIONS || 20),
  prefix: safePrefix,
  botName: process.env.BOT_NAME || 'MINI BOT',
  ownerName: process.env.OWNER_NAME || '',
  ownerNumber: (process.env.OWNER_NUMBER || '').replace(/\D/g, ''),
  owner2Name: process.env.OWNER2_NAME || '𝚉𝙰𝚈𝙰𝙽 𝙱𝙱𝚉 𓆪',
  owner2Number: (process.env.OWNER2_NUMBER || '').replace(/\D/g, ''),
  newsletterLink: process.env.NEWSLETTER_LINK || 'https://whatsapp.com/channel/0029VbDJV7LKGGGI3IIBXR0r',
  newsletterLink2: process.env.NEWSLETTER_LINK_2 || 'https://whatsapp.com/channel/0029VbDOLutAe5ViNznQ5Z1M',
  // optional: your Telegram bot's @username, shown in the welcome message
  // so new group members know where to go to get /pair their own group.
  telegramBotUsername: (process.env.TELEGRAM_BOT_USERNAME || '').replace(/^@/, ''),
  telegramPairGroup: process.env.TELEGRAM_PAIR_GROUP || 'https://t.me/radskybot',
  aiKey: process.env.AI_API_KEY || '',
  aiBase: process.env.AI_BASE_URL || 'https://api.openai.com/v1',
  aiModel: process.env.AI_MODEL || 'gpt-4o-mini',
  antiWords: list(process.env.ANTI_WORDS),
  dataDir: process.env.DATA_DIR || './data',
  port: Number(process.env.PORT || 3000)
};
