import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { num } from './util.js';

const assetDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'assets');
const videoPath = path.join(assetDir, 'welcome.mp4');
let cached;

async function video() {
  if (cached === undefined) cached = await fs.readFile(videoPath).catch(() => null);
  return cached;
}

export const brandFooter = '\n\n> *✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉*';
const frameTop = '╭ׂ┄─̇─̣┄─̇─̣┄─̇─̣─̇─̣─᛭';
const frameSep = '│─̇─̣┄┄┄┄┄┄┄┄┄┄┄┄┄─̇─̣';
const frameBottom = '╰┄─̣┄─̇─̣┄─̇─̣┄─̇─̣─᛭';
const header = (title) => `${frameTop}\n│ ╌─̇─̣⊰ ${title} ⊱┈─̇─̣╌\n${frameSep}`;

export async function sendVideoMessage(sock, jid, caption, quoted) {
  const buf = await video();
  if (buf) return sock.sendMessage(jid, { video: buf, caption }, { quoted });
  return sock.sendMessage(jid, { text: caption }, { quoted });
}

export async function sendMenuMessage(sock, jid, caption, quoted) {
  const buf = await video();
  if (buf) return sock.sendMessage(jid, { video: buf, caption: caption + brandFooter, gifPlayback: false }, { quoted });
  return sock.sendMessage(jid, { text: caption + brandFooter }, { quoted });
}

const channels = () => [
  `📢 *Channel 1:*\n${config.newsletterLink}`,
  `📢 *Channel 2:*\n${config.newsletterLink2}`,
  `🤖 *Telegram Pair Group:*\n${config.telegramPairGroup}`
].join('\n\n');

export function connectedCaption(phone) {
  const ping = Math.max(0, Date.now() % 100);
  return `${header('👑 ◆𓆩 𝙰𝚁𝚄 𝙱𝙱𝚉 𓆪 ◆ 👑')}\n` +
    `│❀ 🤖 𝘽𝙤𝙩 : ◆𓆩 𝙰𝚁𝚄 𝙱𝙱𝚉 𓆪\n` +
    `│❀ 👑 𝙊𝙬𝙣𝙚𝙧 : ${config.ownerName || 'ᵃʳᵘ 𝙱𝙱𝚉 🚬'}\n` +
    `│❀ 🔣 𝙋𝙧𝙚𝙛𝙞𝙭 : ${config.prefix}\n` +
    `│❀ 🔖 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : 1.0.0\n` +
    `│❀ 📶 𝙎𝙩𝙖𝙩𝙪𝙨 : Online 🟢\n` +
    `│❀ 🏓 𝙋𝙞𝙣𝙜 : ${ping} ms\n${frameBottom}\n\n` +
    `✅ 𝑩𝑶𝑻 𝑺𝑼𝑪𝑪𝑬𝑺𝑺𝑭𝑼𝑳𝑳𝒀 𝑪𝑶𝑵𝑵𝑬𝑪𝑻𝑬𝑫 ✅\n\n` +
    `> \`👑 𝑾𝑬𝑳𝑪𝑶𝑴𝑬 𝑻𝑶 𝑶𝑼𝑹 𝑩𝑶𝑻\`\n` +
    `> \`💬 মেনু দেখতে ${config.prefix}menu লিখো\`\n\n` +
    `> \`✨ গ্রুপের রুলস মেনে চলো\`\n` +
    `> \`💬 সবাই মিলে আড্ডা দাও, মজা করো\`\n` +
    `> \`🚫 লিংক / গালি / স্প্যাম দিও না\`\n\n` +
    `${channels()}\n\n> \`✅ চ্যানেল ২ টা Follow করে দাও\`\n> \`🔔 আপডেট সবার আগে পেতে\`` + brandFooter;
}

export async function connectedMessage({ phone }) {
  const caption = connectedCaption(phone);
  const buf = await video();
  if (buf) return { video: buf, caption, gifPlayback: false };
  return { text: caption };
}

export async function welcomeMessage({ groupName, mentions, memberCount = 0 }) {
  const names = mentions.map((j) => '@' + num(j)).join(' ');
  const caption = `${header('🌸 𝙒𝙀𝙇𝘾𝙊𝙈𝙀')}\n` +
    `│❀ 👋 𝙒𝙚𝙡𝙘𝙤𝙢𝙚 : ${names}\n` +
    `│❀ 📍 𝙂𝙧𝙤𝙪𝙥 : ${groupName}\n` +
    `│❀ 👥 𝙈𝙚𝙢𝙗𝙚𝙧𝙨 : ${memberCount}\n` +
    `│❀ 🤖 𝘽𝙤𝙩 : ${config.botName}\n` +
    `│❀ 👑 𝙊𝙬𝙣𝙚𝙧 : ${config.ownerName || 'ᵃʳᵘ 𝙱𝙱𝚉 🚬'}\n${frameBottom}\n\n` +
    `🌸 ⃝ 𝑾𝑬𝑳𝑪𝑶𝑴𝑬 𝑻𝑶 𝑶𝑼𝑹 𝑮𝑹𝑶𝑼𝑷 ⃝ 🌸\n\n` +
    `> \`✨ গ্রুপের রুলস মেনে চলো\`\n> \`💬 সবাই মিলে আড্ডা দাও, মজা করো\`\n> \`🚫 লিংক / গালি / স্প্যাম দিও না\`` + brandFooter;
  const buf = await video();
  if (buf) return { video: buf, caption, mentions, gifPlayback: false };
  return { text: caption, mentions };
}

export async function goodbyeMessage({ groupName, mentions, memberCount = 0 }) {
  const names = mentions.map((j) => '@' + num(j)).join(' ');
  const caption = `${header('💔 𝙂𝙊𝙊𝘿𝘽𝙔𝙀')}\n` +
    `│❀ 👋 𝙂𝙤𝙤𝙙𝙗𝙮𝙚 : ${names}\n` +
    `│❀ 📍 𝙂𝙧𝙤𝙪𝙥 : ${groupName}\n` +
    `│❀ 👥 𝙈𝙚𝙢𝙗𝙚𝙧𝙨 : ${memberCount}\n` +
    `│❀ 🤖 𝘽𝙤𝙩 : ${config.botName}\n` +
    `│❀ 👑 𝙊𝙬𝙣𝙚𝙧 : ${config.ownerName || 'ᵃʳᵘ 𝙱𝙱𝚉 🚬'}\n${frameBottom}\n\n` +
    `💔 ⃝ 𝑮𝑶𝑶𝑫𝑩𝒀𝑬 𝑭𝑹𝑶𝑴 𝑶𝑼𝑹 𝑮𝑹𝑶𝑼𝑷 ⃝ 💔\n\n` +
    `> \`😔 মিস করবো তোমায়\`\n> \`💗 ভালো থেকো, আবার ফিরে এসো\`\n> \`👑 ${groupName} তোমাকে মনে রাখবে\`` + brandFooter;
  const buf = await video();
  if (buf) return { video: buf, caption, mentions, gifPlayback: false };
  return { text: caption, mentions };
}
