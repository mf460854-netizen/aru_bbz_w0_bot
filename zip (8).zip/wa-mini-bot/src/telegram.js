import { Telegraf, Markup, Input } from 'telegraf';
import QRCode from 'qrcode';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { esc, normalizePhone } from './util.js';
import { setNotifier, startSession, removeSession, getStatus, countSessions, listAll, listForOwner } from './wa.js';

const cooldown = new Map();
const identities = (ctx) => [String(ctx.from?.id || ''), ctx.from?.username ? `@${ctx.from.username}` : ''].filter(Boolean);
const matches = (list, ctx) => identities(ctx).some((x) => list.includes(x) || list.includes(x.replace(/^@/, '')));
const isAdmin = (ctx) => matches(config.adminIds, ctx);
// Telegram pairing is intentionally open to every private user. Admin-only
// operations such as /sessions still use isAdmin() below.
const allowed = () => true;
const html = { parse_mode: 'HTML' };
const videoPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'assets', 'welcome.mp4');
const botTitle = () => `✦ <b>${esc(config.botName)}</b> ✦`;
const card = (title, body = '') => `╭──────────────╮\n│ ${botTitle()}\n╰──────────────╯\n<b>${title}</b>${body ? `\n\n${body}` : ''}\n\n✦ <i>Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉</i>`;
const label = (phone) => `📱 Pairing number: <code>+${esc(phone)}</code>`;
const copyKeyboard = (raw) => ({ inline_keyboard: [[{ text: '📋 Copy pairing code', copy_text: { text: raw } }]] });
const sendQrDirect = async (id, png, caption) => {
  const form = new FormData();
  form.append('chat_id', String(id));
  form.append('parse_mode', 'HTML');
  form.append('caption', caption);
  form.append('photo', new Blob([png], { type: 'image/png' }), 'pairing-qr.png');
  const res = await fetch(`https://api.telegram.org/bot${config.tgToken}/sendPhoto`, {
    method: 'POST', body: form, signal: AbortSignal.timeout(20_000)
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Telegram QR upload ${res.status}: ${body.slice(0, 160)}`);
  return body;
};

export function startTelegram() {
  if (!config.tgToken) {
    console.error('❌ TELEGRAM_BOT_TOKEN সেট করা নেই (.env দেখুন)');
    process.exit(1);
  }
  const bot = new Telegraf(config.tgToken);
  const sendCard = (id, text, options = {}) => bot.telegram.sendMessage(id, text, { ...html, ...options }).catch((e) => {
    console.error('[telegram sendMessage]', e.message);
    return null;
  });
  const sendVideoCard = async (id, text, options = {}) => {
    try {
      return await bot.telegram.sendVideo(id, Input.fromLocalFile(videoPath), { caption: text, ...html, ...options });
    } catch (e) {
      console.error('[telegram sendVideo]', e.message);
      return sendCard(id, text, options);
    }
  };
  setNotifier((id, text, extra = {}) => {
    return extra.connected ? sendVideoCard(id, text) : sendCard(id, card('WhatsApp status', text));
  });

  bot.use((ctx, next) => {
    if (ctx.chat?.type !== 'private') return next();
    if (!allowed(ctx)) return ctx.reply(card('Access denied', '⛔ এই বট ব্যবহারের অনুমতি আপনার নেই।'), html);
    return next();
  });

  const help = card('Telegram pairing center',
    `📱 <code>/pair 01886030719</code> — phone pairing code\n` +
    `📷 <code>/pair2</code> — QR scan pairing\n` +
    `📶 <code>/status</code> — connection status\n` +
    `🗑️ <code>/unlink</code> — remove session\n\n` +
    `শুধু নিজের WhatsApp নম্বর পেয়ার করুন।`);
  bot.start((ctx) => sendVideoCard(ctx.from.id, help));
  bot.help((ctx) => sendVideoCard(ctx.from.id, help));

  const canStart = (id, sessionId) => {
    const st = getStatus(sessionId);
    if (st && ['open', 'connecting'].includes(st.state)) return 'এই নম্বরের একটি session ইতিমধ্যে চলছে। অন্য নম্বর দিন অথবা সেই নম্বর দিয়ে /unlink করুন।';
    const cooldownKey = `${id}:${sessionId}`;
    if (Date.now() - (cooldown.get(cooldownKey) || 0) < 10_000) return '⏳ কয়েক সেকেন্ড পরে আবার চেষ্টা করুন।';
    if (!st && countSessions() >= config.maxSessions) return '🚫 Server session limit পূর্ণ হয়েছে।';
    cooldown.set(cooldownKey, Date.now());
    return null;
  };

  bot.command('pair', async (ctx) => {
    const id = String(ctx.from.id);
    const phone = normalizePhone(ctx.message.text.split(/\s+/)[1] || '');
    if (!phone) return ctx.reply(card('Number required', 'সঠিক উদাহরণ: <code>/pair 01886030719</code>'), html);
    if (!/^\d{8,15}$/.test(phone)) return ctx.reply(card('Invalid number', 'শুধু digits সহ country code দিন। উদাহরণ: <code>/pair 01886030719</code>'), html);
    const sessionId = `${id}:${phone}`;
    const problem = canStart(id, sessionId);
    if (problem) return ctx.reply(card('Pairing unavailable', problem), html);
    await sendCard(id, card('Pairing started', `${label(phone)}\n⏳ WhatsApp pairing code তৈরি হচ্ছে…`));
    startSession(sessionId, {
      ownerId: id,
      phone,
      onCode: (code, err) => {
        if (!code) return sendCard(id, card('Pairing failed', `${label(phone)}\n❌ ${esc(err?.message || 'কোড পাওয়া যায়নি')}`));
        const pretty = `${code.slice(0, 4)}-${code.slice(4)}`;
        const text = card('Your pairing code', `${label(phone)}\n\n🔑 <code>${pretty}</code>\n📋 Copy button-এ hyphen ছাড়া 8-digit code থাকবে।\n\n` +
          `WhatsApp → Linked devices → Link a device → Link with phone number instead\n` +
          `কোডটি শুধু 8টি digit হিসেবে দিন, hyphen নয়।\n` +
          `⏱️ ২ মিনিটের মধ্যে code দিন।`);
        return sendCard(id, text, { reply_markup: copyKeyboard(code) });
      }
    }).catch((e) => sendCard(id, card('Pairing error', esc(e.message))));
  });

  bot.command('pair2', async (ctx) => {
    const id = String(ctx.from.id);
    const sessionId = `${id}:qr:${Date.now()}`;
    const problem = canStart(id, sessionId);
    if (problem) return ctx.reply(card('QR pairing unavailable', problem), html);
    await sendCard(id, card('QR pairing started', '⏳ QR তৈরি হচ্ছে…'));
    let lastQr = '';
    let lastQrAt = 0;
    startSession(sessionId, {
      ownerId: id,
      onQr: async (qr) => {
        if (qr === lastQr && Date.now() - lastQrAt < 15_000) return;
        lastQr = qr;
        lastQrAt = Date.now();
        try {
          const png = await QRCode.toBuffer(qr, { type: 'png', width: 420, margin: 1, errorCorrectionLevel: 'M' });
          const captionText = card('Scan this QR', 'WhatsApp → Linked devices → Link a device দিয়ে QR scan করুন।');
          try {
            await sendQrDirect(id, png, captionText);
          } catch (photoError) {
            console.error('[qr direct photo]', photoError.message);
            await ctx.telegram.sendDocument(id, Input.fromBuffer(png, 'pairing-qr.png'), { caption: captionText, ...html });
          }
        } catch (e) {
          console.error('[qr send]', e.message);
          await sendCard(id, card('QR delivery failed', 'Telegram photo/document upload ব্যর্থ হয়েছে। Internet connection চেক করে একবার /pair2 দিন।'));
        }
      }
    }).catch((e) => sendCard(id, card('QR pairing error', esc(e.message))));
  });

  bot.command('status', (ctx) => {
    const all = listForOwner(String(ctx.from.id));
    if (!all.length) return sendCard(ctx.from.id, card('Status', 'কোনো session নেই। /pair অথবা /pair2 দিয়ে শুরু করুন।'));
    const rows = all.map((s, i) => `${i + 1}. 📱 ${s.phone ? '+' + esc(s.phone) : 'QR session'} — <b>${s.state}</b>`).join('\n');
    return sendCard(ctx.from.id, card('Connection status', rows));
  });

  bot.command('unlink', (ctx) => {
    const all = listForOwner(String(ctx.from.id));
    if (!all.length) return sendCard(ctx.from.id, card('Unlink', 'ডিলিট করার মতো কোনো session নেই।'));
    const wanted = normalizePhone(ctx.message.text.split(/\s+/)[1] || '');
    const match = wanted ? all.find((s) => s.phone === wanted) : all.length === 1 ? all[0] : null;
    if (!match) return sendCard(ctx.from.id, card('Choose a session', all.length > 1
      ? 'একাধিক session আছে। নির্দিষ্ট নম্বর দিয়ে unlink করুন, যেমন:\n<code>/unlink 01886030719</code>'
      : 'সেশনটি এখনো connected হয়নি। কিছুক্ষণ পরে আবার চেষ্টা করুন।'));
    const token = encodeURIComponent(match.id);
    return ctx.telegram.sendVideo(ctx.from.id, Input.fromLocalFile(videoPath), { caption: card('Confirm unlink', `📱 +${esc(match.phone || 'QR session')}\nসত্যিই এই session ডিলিট করবেন?`), ...html, reply_markup: Markup.inlineKeyboard([
      Markup.button.callback('✅ হ্যাঁ, ডিলিট', `unlink_yes:${token}`), Markup.button.callback('❌ না', 'unlink_no')
    ]).reply_markup });
  });
  bot.action(/^unlink_yes:(.+)$/, async (ctx) => {
    await removeSession(decodeURIComponent(ctx.match[1]), { logout: true });
    await ctx.editMessageText(card('Unlinked', '🗑️ Session ডিলিট হয়েছে।'), html).catch(() => {});
    return ctx.answerCbQuery();
  });
  bot.action('unlink_no', async (ctx) => { await ctx.editMessageText(card('Cancelled', 'কোনো পরিবর্তন করা হয়নি।'), html).catch(() => {}); return ctx.answerCbQuery(); });

  bot.command('sessions', (ctx) => {
    if (!isAdmin(ctx)) return;
    const all = listAll();
    return ctx.reply(card('All sessions', `📊 মোট: ${all.length}/${config.maxSessions}\n` +
      (all.map((s) => `${s.id} — ${s.state}${s.phone ? ' +' + s.phone : ''}`).join('\n') || '—')), html);
  });

  bot.catch((e) => console.error('[telegram]', e.message));
  bot.telegram.getMe()
    .then((me) => console.log(`✅ Telegram verified: @${me.username || me.id}`))
    .then(() => bot.launch({ dropPendingUpdates: true }))
    .then(() => console.log('✅ Telegram polling started'))
    .catch((e) => console.error('[telegram startup]', e.message));
  process.once('SIGINT', () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
}
