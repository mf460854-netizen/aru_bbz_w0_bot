export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// "123:4@s.whatsapp.net" -> "123"
export const num = (jid) => String(jid || '').split('@')[0].split(':')[0];

// Normalize common international/Bangladesh inputs for Baileys pairing.
export function normalizePhone(value) {
  let s = String(value || '').trim().replace(/[^\d]/g, '');
  if (s.startsWith('00')) s = s.slice(2);
  // Accept local Bangladeshi 01XXXXXXXXX input as +8801XXXXXXXXX.
  if (s.startsWith('01') && s.length === 11) s = '88' + s;
  return s;
}

// every identifier a participant object may carry (LID / phone JID)
export const idsOf = (p) => [p?.id, p?.lid, p?.phoneNumber, p?.jid].filter(Boolean).map(num);

export function unwrap(message) {
  let cur = message;
  for (let i = 0; i < 4; i++) {
    const inner =
      cur?.ephemeralMessage?.message ||
      cur?.viewOnceMessage?.message ||
      cur?.viewOnceMessageV2?.message ||
      cur?.documentWithCaptionMessage?.message ||
      cur?.editedMessage?.message;
    if (!inner) break;
    cur = inner;
  }
  return cur || {};
}

export function contextOf(message) {
  const m = unwrap(message);
  const k = Object.keys(m).find((key) => m[key] && typeof m[key] === 'object' && m[key].contextInfo);
  return k ? m[k].contextInfo : undefined;
}

export function tsOf(t) {
  if (!t) return 0;
  if (typeof t === 'number') return t;
  if (typeof t.toNumber === 'function') return t.toNumber();
  return Number(t) || 0;
}

export function fmtUptime(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return `${h}h ${m}m ${s}s`;
}

export const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
