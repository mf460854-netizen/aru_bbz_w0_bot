# WA Mini Bot (Telegram-paired)

Telegram বটে `/pair <নম্বর>` দিলে WhatsApp-এর **পেয়ার কোড** আসে। দেশের কোডসহ নম্বর (যেমন `8801712345678`) বা বাংলাদেশের লোকাল নম্বর (যেমন `01712345678`) দুটোই গ্রহণ করে। কোডটা WhatsApp → Linked devices → *Link with phone number* এ দিলেই বট চালু।
`/pair2` দিলে QR code আসে; WhatsApp → Linked devices → *Link a device* দিয়ে QR scan করলেও বট কানেক্ট হবে।

## ওয়েবসাইট
বট চালু হলে একটা স্ট্যাটাস ওয়েবসাইটও চালু হয় (`PORT`, ডিফল্ট 3000):
- `/` — ARU BBZ থিমে ব্র্যান্ডেড পেজ: লাইভ স্ট্যাটাস, কানেক্টেড সেশন সংখ্যা, Uptime, Telegram বট ও চ্যানেল লিংক
- `/health` — `200 ok`, Render/Replit-এর মতো ফ্রি হোস্টে বট ঘুমিয়ে না পড়ার জন্য (uptime monitor দিয়ে পিং করুন)
- `/api/status` — JSON স্ট্যাটাস, কোনো ফোন নম্বর বা ইউজার আইডি এখানে দেখায় না (পাবলিক পেজ বলে)

পুরো সেশন তালিকা (কে কে পেয়ার করেছে, নম্বরসহ) শুধু Telegram-এ `/sessions` (ADMIN_IDS) দিয়ে দেখা যায়, ওয়েবসাইটে না — প্রাইভেসির জন্য।

## Render-এ ফ্রি হোস্ট করা
1. **⚠️ আগে `.env` ফাইলটা ডিলিট করুন বা নাম বদলে রাখুন** — GitHub-এ আপলোড করার সময় এটা যেন না যায়, কারণ এতে আপনার আসল Telegram টোকেন আছে। `.gitignore`-এ `.env` বাদ দেওয়া আছে, কিন্তু GitHub-এর "Upload files" দিয়ে টানলে `.gitignore` কাজ করে না — হাতে বাদ দিয়ে আপলোড করুন।
2. এই পুরো ফোল্ডারটা GitHub-এ একটা **নতুন প্রাইভেট রিপো**তে পুশ করুন (GitHub ওয়েবসাইট থেকে "Upload files" দিয়েও করা যায়, `git` না জানলেও চলবে)।
3. [render.com](https://render.com) এ গিয়ে সাইন আপ করুন (GitHub দিয়ে লগইন করলে সহজ হয়)।
4. **New +** → **Web Service** → আপনার রিপো সিলেক্ট করুন। Render নিজে থেকেই এই প্রজেক্টের `Dockerfile` খুঁজে পাবে (Environment: Docker)।
5. **Environment Variables** এ গিয়ে অন্তত এগুলো বসান (বাকিগুলো `render.yaml`-এ আগে থেকেই আছে):
   - `TELEGRAM_BOT_TOKEN` = আপনার টোকেন
   - `ADMIN_IDS` = আপনার Telegram numeric ID
   - `TELEGRAM_BOT_USERNAME` = আপনার বটের @username (@ ছাড়া)
6. **Health Check Path**: `/health` (এটা bot ঘুমিয়ে পড়া আটকায় না, শুধু Render কে বোঝায় সার্ভিস জীবিত)
7. **Create Web Service** চাপুন। ২–৫ মিনিটে ডেপ্লয় শেষ হবে, Render একটা লিংক দেবে (যেমন `https://aru-bbz-bot.onrender.com`) — ওটাই আপনার ওয়েবসাইট।

### Render ফ্রি টায়ারের সীমাবদ্ধতা (জানা জরুরি)
- ১৫ মিনিট কেউ না ব্যবহার করলে সার্ভিস ঘুমিয়ে যায়, পরের রিকোয়েস্টে আবার জাগতে ৩০–৫০ সেকেন্ড লাগে। এটা ঠেকাতে [UptimeRobot](https://uptimerobot.com) (ফ্রি) দিয়ে প্রতি ৫ মিনিটে আপনার `/health` URL-এ পিং করান।
- ফ্রি টায়ারে **persistent disk নেই** — মানে রিডেপ্লয় বা দীর্ঘ স্লিপের পর `data/sessions/` ফোল্ডার মুছে যেতে পারে, তখন সবাইকে আবার `/pair` করতে হবে। এটা এড়াতে Render-এর পেইড "Persistent Disk" অ্যাড-অন লাগবে (সস্তা, ~$1/month থেকে শুরু)।

## চালানোর ধাপ (লোকালি)
1. @BotFather থেকে Telegram বট বানিয়ে টোকেন নিন।
2. `cp .env.example .env` → `TELEGRAM_BOT_TOKEN`, `ADMIN_IDS`, `ALLOWED_IDS` ভরুন। নিজের ব্র্যান্ডিং ও owner তথ্য চাইলে `BOT_NAME`, `OWNER_NAME`, `OWNER_NUMBER`, `NEWSLETTER_LINK` সেট করুন।
3. `npm install` (হোস্টে `git` লাগতে পারে) → `npm start`
4. (ঐচ্ছিক) স্টিকারের জন্য `ffmpeg` ইনস্টল করুন।

## Telegram কমান্ড
`/pair 8801XXXXXXXXX` • `/pair2` • `/status` • `/unlink` • `/sessions` (admin)

## WhatsApp কমান্ড (প্রিফিক্স `/`)
general: menu ping alive owner channel id • ai: ai • tools: sticker
group: tagall hidetag kick promote demote mute unmute link del antilink antispam welcome groupinfo
owner: mode (self/public) prefix sudo

## অটোমেটিক গ্রুপ ফিচার (প্রতি গ্রুপে ডিফল্ট: ON)
- **antilink** — যেকোনো non-admin মেম্বার `chat.whatsapp.com` লিংক দিলে মেসেজ সাথে সাথে ডিলিট। বন্ধ করতে: `.antilink off`
- **antispam** — কেউ ১০ সেকেন্ডে ৭টার বেশি মেসেজ দিলে (ফ্লাড/স্প্যাম) তাকে অটো-কিক করে, **শুধু বট নিজে অ্যাডমিন থাকলে**। বন্ধ করতে: `.antispam off`
- **welcome** — নতুন কেউ গ্রুপে জয়েন করলে তাকে @mention করে, গ্রুপের নাম ও বটের নাম সহ `assets/welcome.mp4` ভিডিওটা ওয়েলকাম মেসেজ হিসেবে পাঠায়। বন্ধ করতে: `.welcome off`
  - ক্যাপশনে Telegram বটের `/pair` লিংক দেখাতে `.env`-এ `TELEGRAM_BOT_USERNAME` দিন (@ ছাড়া)।
- এই তিনটাই গ্রুপ-অ্যাডমিন/owner-কে স্পর্শ করে না, শুধু সাধারণ মেম্বারদের জন্য প্রযোজ্য।

## Owner (OWNER_NUMBER)
`.env`-এর `OWNER_NUMBER` যে কোনো প্যায়ার্ড সেশনে owner হিসেবে কাজ করে —
সেই সেশনের `mode` যদি `self` (private) থাকে, তাও আপনার নম্বর থেকে কমান্ড চলবে।

## নিরাপত্তা
- `eval`, অবফাসকেশন, রিমোট-আপডেট নেই। ffmpeg চলে `spawn` (আর্গুমেন্ট অ্যারে) দিয়ে।
- সেশন `data/sessions/<telegram-id>/` এ, কোথাও পাঠানো হয় না। `/unlink` দিলে ডিলিট।
- `ALLOWED_IDS` দিয়ে কারা পেয়ার করতে পারবে সীমিত করুন।
- ডিফল্ট মোড `self` (শুধু owner)।
- **এই বট কারো অজান্তে তার গ্রুপ-লিংক সংগ্রহ করে না, বা কাউকে অন্যের গ্রুপে অনুমতি ছাড়া
  অ্যাডমিন বানায় না।** এমন ফিচার ইচ্ছা করেই বাদ দেওয়া হয়েছে, কারণ এটা গ্রুপ হাইজ্যাকিং/
  প্রাইভেসি লঙ্ঘনের টুল হয়ে যায়। প্রতিটা WhatsApp নম্বর শুধু নিজের গ্রুপেই
  অ্যাডমিন কমান্ড চালাতে পারবে।
