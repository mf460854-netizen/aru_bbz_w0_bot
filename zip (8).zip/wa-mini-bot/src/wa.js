import fs from 'node:fs';
import path from 'node:path';
import pino from 'pino';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers
} from '@whiskeysockets/baileys';
import { config } from './config.js';
import { getSettings, saveSettings, dropSettings } from './store.js';
import { handleMessage, handleParticipants } from './handler.js';
import { connectedMessage, connectedCaption } from './welcome.js';
import { num, sleep } from './util.js';

const logger = pino({ level: 'silent' });
const sessions = new Map(); // tgId -> meta
const PAIR_TIMEOUT_MS = 120_000;
let waVersion;
let notify = () => {};

export const setNotifier = (fn) => { notify = fn; };
const sessionDir = (id) => path.join(config.dataDir, 'sessions', String(id));

async function getVersion() {
  if (waVersion) return waVersion;
  try { waVersion = (await fetchLatestBaileysVersion()).version; } catch {}
  return waVersion; // undefined -> Baileys default
}

export const countSessions = () => sessions.size;
export const getStatus = (id) => {
  const m = sessions.get(String(id));
  return m ? { state: m.status, phone: getSettings(id).phone } : null;
};
export const listAll = () => [...sessions.entries()].map(([id, m]) => ({ id, state: m.status, phone: getSettings(id).phone }));
export const listForOwner = (ownerId) => [...sessions.entries()]
  .filter(([id, m]) => String(m.ownerId || id.split(':')[0]) === String(ownerId))
  .map(([id, m]) => ({ id, state: m.status, phone: getSettings(id).phone }));

export async function startSession(id, { phone, onCode, onQr, ownerId } = {}) {
  id = String(id);
  if (sessions.has(id)) await removeSession(id);
  const meta = {
    phone, onCode, onQr, ownerId: String(ownerId || String(id).split(':')[0]), status: 'connecting', retries: 0, stopped: false,
    sock: null, groupCache: new Map(), pairTimer: null, retryTimer: null
  };
  sessions.set(id, meta);
  await connect(id, meta);
}

async function connect(id, meta) {
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir(id));
  const pairing = !state.creds.registered && !!meta.phone;
  const qrPairing = !state.creds.registered && !meta.phone && !!meta.onQr;

  // leftover half-finished pairing from an old run: clean it up
  if (!state.creds.registered && !meta.phone && !meta.onQr) {
    await removeSession(id);
    return;
  }

  const sock = makeWASocket({
    version: await getVersion(),
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    logger,
    browser: Browsers.ubuntu(config.botName.replace(/[^\x20-\x7e]/g, '').trim() || 'Bot'),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    shouldSyncHistoryMessage: () => false,
    getMessage: async () => undefined,
    cachedGroupMetadata: async (jid) => meta.groupCache.get(jid)?.data
  });
  meta.sock = sock;

  // group metadata cache (60s) keeps group commands fast and avoids rate limits
  sock.getGroup = async (jid) => {
    const c = meta.groupCache.get(jid);
    if (c && Date.now() - c.t < 60_000) return c.data;
    const data = await sock.groupMetadata(jid);
    meta.groupCache.set(jid, { data, t: Date.now() });
    return data;
  };

  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('groups.update', (ups) => ups.forEach((u) => meta.groupCache.delete(u.id)));
  sock.ev.on('group-participants.update', (ev) => {
    meta.groupCache.delete(ev.id);
    if (!meta.stopped) handleParticipants(sock, ev, id).catch((e) => console.error('[welcome]', e.message));
  });
  sock.ev.on('messages.upsert', ({ messages }) => {
    if (meta.stopped) return;
    for (const m of messages) handleMessage(sock, m, id).catch((e) => console.error('[msg]', e.message));
  });

  let requested = false;
  sock.ev.on('connection.update', async (u) => {
    if (meta.stopped || meta.sock !== sock) return;
    const { connection, lastDisconnect, qr } = u;

    if (qr && qrPairing) meta.onQr?.(qr);

    // WhatsApp is ready for the handshake -> ask for the pairing code
    if (qr && pairing && !requested) {
      requested = true;
      try {
        const code = await sock.requestPairingCode(meta.phone);
        meta.pairTimer = setTimeout(async () => {
          if (meta.status !== 'open') {
            await removeSession(id);
            notify(meta.ownerId, '⌛ ২ মিনিটে লিঙ্ক হয়নি, পেয়ারিং বাতিল। আবার /pair দিন।', { video: true });
          }
        }, PAIR_TIMEOUT_MS);
        meta.onCode?.(code);
      } catch (e) {
        meta.onCode?.(null, e);
        await removeSession(id);
      }
    }

    if (connection === 'open') {
      clearTimeout(meta.pairTimer);
      meta.status = 'open';
      meta.retries = 0;
      const s = getSettings(id);
      s.phone = num(sock.user?.id);
      saveSettings(id);
      const selfJid = sock.user?.id || `${s.phone}@s.whatsapp.net`;
      sock.sendMessage(selfJid, await connectedMessage({ phone: s.phone })).catch((e) => console.error('[connected-welcome]', e.message));
      notify(meta.ownerId, connectedCaption(s.phone), { connected: true });
    }

    if (connection === 'close') {
      meta.status = 'connecting';
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code === DisconnectReason.loggedOut) {
        await removeSession(id);
        return notify(meta.ownerId, '⚠️ WhatsApp থেকে লগআউট হয়েছে, সেশন ডিলিট। আবার /pair দিন।', { video: true });
      }
      if (code === DisconnectReason.connectionReplaced) {
        await removeSession(id);
        return notify(meta.ownerId, '⚠️ অন্য জায়গায় একই সেশন চালু হয়েছে, এটি বন্ধ করা হলো।', { video: true });
      }
      if (pairing && !state.creds.registered && code !== DisconnectReason.restartRequired) {
        await removeSession(id);
        return notify(meta.ownerId, '❌ পেয়ারিং ব্যর্থ হয়েছে। আবার /pair দিন।', { video: true });
      }
      // restartRequired (515) happens right after a successful pairing: reconnect fast
      const delay = code === DisconnectReason.restartRequired ? 300 : Math.min(1000 * 2 ** meta.retries++, 30_000);
      meta.retryTimer = setTimeout(() => {
        if (!meta.stopped) connect(id, meta).catch((e) => console.error('[reconnect]', e.message));
      }, delay);
    }
  });
}

export async function removeSession(id, { logout = false } = {}) {
  id = String(id);
  const meta = sessions.get(id);
  if (meta) {
    meta.stopped = true;
    clearTimeout(meta.pairTimer);
    clearTimeout(meta.retryTimer);
    if (logout && meta.status === 'open') { try { await meta.sock.logout(); } catch {} }
    try { meta.sock?.end(undefined); } catch {}
    sessions.delete(id);
  }
  fs.rmSync(sessionDir(id), { recursive: true, force: true });
  dropSettings(id);
}

// bring every previously paired session back after a restart
export async function restoreAll() {
  const root = path.join(config.dataDir, 'sessions');
  if (!fs.existsSync(root)) return;
  for (const id of fs.readdirSync(root)) {
    if (!fs.existsSync(path.join(root, id, 'creds.json'))) continue;
    startSession(id, {}).catch((e) => console.error('[restore]', id, e.message));
    await sleep(1500); // stagger so many sessions don't spike CPU/RAM
  }
}
