import { spawn } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import pino from 'pino';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { config } from './config.js';
import { saveSettings } from './store.js';
import { num, contextOf, unwrap, fmtUptime } from './util.js';
import { sendMenuMessage } from './welcome.js';

const logger = pino({ level: 'silent' });
const started = Date.now();
const list = [];
const add = (def) => list.push(def);

const CATS = { general: '📌 GENERAL', ai: '🤖 AI', tools: '🛠️ TOOLS', group: '👥 GROUP', owner: '👑 OWNER' };
const DEFAULT_ON = new Set(['antilink', 'antispam', 'welcome']);

// users mentioned in the message, or the author of the quoted message
const targets = (c) => {
  const ci = contextOf(c.m.message);
  const ids = new Set(ci?.mentionedJid || []);
  if (!ids.size && ci?.participant) ids.add(ci.participant);
  return [...ids];
};

// these three default to ON for every group; .env is not involved, the group
// only turns a feature off by running e.g. `.antilink off`.
const toggle = (c, key) => {
  const v = (c.args[0] || '').toLowerCase();
  const now = (c.s[key][c.jid] === true || (c.s[key][c.jid] === undefined && DEFAULT_ON.has(key))) ? 'on' : 'off';
  const action = (c.args[1] || '').toLowerCase();
  if (!['on', 'off'].includes(v)) return c.reply(`Usage: ${c.prefix}${key} on|off [delete|warn|kick]\nNow: ${now}\nAction: ${c.s.antiActions[key] || 'delete'}`);
  c.s[key][c.jid] = v === 'on';
  if (['delete', 'warn', 'kick'].includes(action)) c.s.antiActions[key] = action;
  saveSettings(c.id);
  return c.reply(`✅ ${key}: ${v}\n⚙️ Action: ${c.s.antiActions[key] || 'delete'}`);
};

/* ───────── GENERAL ───────── */
const BANNER = `◆𓆩 ${config.botName.replace(/^◆𓆩\s*|\s*𓆪$/g, '')} 𓆪◆`;

add({ name: 'menu', alias: ['help'], cat: 'general', desc: 'কমান্ড তালিকা', run: async (c) => {
  let out = `╭ׂ┄─̇─̣┄─̇─̣┄─̇─̣─̇─̣─᛭\n`
    + `│ ╌─̇─̣⊰ 👑 ${BANNER} 👑 ⊱┈─̇─̣╌\n`
    + `│─̇─̣┄┄┄┄┄┄┄┄┄┄┄┄┄─̇─̣\n`
    + `│❀ 📱 𝐁𝐨𝐭: ${config.botName}\n`
    + `│❀ 🔖 𝐕𝐞𝐫𝐬𝐢𝐨𝐧: 1.0.0\n`
    + `│❀ 👤 𝐎𝐰𝐧𝐞𝐫: ${config.ownerName || '—'}\n`
    + `│❀ 🔣 𝐏𝐫𝐞𝐟𝐢𝐱: ${c.prefix}\n`
    + `│❀ 📊 𝐓𝐨𝐭𝐚𝐥 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: ${list.length}\n`
    + `│❀ ⚡ 𝐒𝐭𝐚𝐭𝐮𝐬: Fast • Protected • AI\n`
    + `╰┄─̣┄─̇─̣┄─̇─̣┄─̇─̣─᛭\n`;
  for (const [k, label] of Object.entries(CATS)) {
    const items = list.filter((x) => x.cat === k);
    if (!items.length) continue;
    out += `\n╭ׂ┄─̇─̣┄─̇─̣┄─̇─̣─̇─̣─᛭\n`;
    out += `│ ╌─̇─̣⊰ ${label} ⊱┈─̇─̣╌\n`;
    out += `│─̇─̣┄┄┄┄┄┄┄┄┄┄┄┄┄─̇─̣\n`;
    out += items.map((x) => `│❀ ${c.prefix}${x.name}`).join('\n') + '\n';
    out += '╰┄─̣┄─̇─̣┄─̇─̣┄─̇─̣─᛭\n';
  }
  out += `\n💡 ব্যবহার: ${c.prefix}command [argument]\n`;
  out += `👑 Owner: ${config.ownerName || '—'}\n\n`;
  out += `> *✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉*`;
  return sendMenuMessage(c.sock, c.jid, out.trim(), c.m);
} });

add({ name: 'ping', cat: 'general', desc: 'স্পিড টেস্ট', run: (c) =>
  c.reply(`╭─⊱ 👑 ${BANNER} 👑 ⊰─╮\n│ 🏓 Pong!\n│ ⚡ Speed : ${Math.max(0, Date.now() - c.msgTime)}ms\n│ 📶 Status : Online 🟢\n│ 🤖 Bot : ${config.botName}\n╰───────────────────╯\n> *✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉*`) });

add({ name: 'alive', cat: 'general', desc: 'বট চালু আছে কিনা', run: (c) =>
  c.reply(`╭─⊱ 🟢 ONLINE ⊰─╮\n│ ${BANNER}\n│ ⏱️ Uptime: ${fmtUptime((Date.now() - started) / 1000)}\n╰───────────────────╯`) });

add({ name: 'owner', cat: 'general', desc: 'owner-এর তথ্য', run: (c) => {
  const owners = [
    { name: config.ownerName || 'Owner', number: config.ownerNumber || c.s.phone },
    { name: config.owner2Name || '𝚉𝙰𝚈𝙰𝙽 𝙱𝙱𝚉 𓆪', number: config.owner2Number }
  ].filter((x) => x.number);
  const contacts = owners.map(({ name, number }) => ({ vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL;type=CELL;waid=${number}:+${number}\nEND:VCARD` }));
  return c.sock.sendMessage(c.jid, { contacts: { displayName: owners.map((x) => x.name).join(' & '), contacts } }, { quoted: c.m });
} });

add({ name: 'getpp', alias: ['pp', 'profilepic', 'avatar', 'dp'], cat: 'general', desc: 'get profile picture', run: async (c) => {
  const target = targets(c)[0] || c.senderJids.find(Boolean) || c.jid;
  try {
    const url = await c.sock.profilePictureUrl(target, 'image');
    const res = await fetch(url, { signal: AbortSignal.timeout(15_000) });
    if (!res.ok) throw new Error('profile image unavailable');
    const image = Buffer.from(await res.arrayBuffer());
    return c.sock.sendMessage(c.jid, { image, caption: `╭─⊱ 📸 PROFILE PICTURE ⊰─╮\n│ 👤 User: +${num(target)}\n╰───────────────────╯\n> *✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉*` }, { quoted: c.m });
  } catch {
    return c.reply(`📸 No profile picture found for +${num(target)}.`);
  }
} });

add({ name: 'channel', alias: ['newsletter'], cat: 'general', desc: 'অফিসিয়াল চ্যানেল', run: (c) =>
  c.reply(config.newsletterLink ? `╭─⊱ 📢 OFFICIAL CHANNEL ⊰─╮\n│ ${config.newsletterLink}\n╰────────────────────────╯\nনিজে খুলে Follow করুন।` : 'চ্যানেল সেট করা নেই।') });

add({ name: 'id', cat: 'general', desc: 'চ্যাটের JID', run: (c) => c.reply(c.jid) });

/* ───────── FUN ───────── */
add({ name: 'dice', cat: 'general', desc: 'ডাইস খেলুন', run: (c) => c.reply(`🎲 ফলাফল: <b>${1 + Math.floor(Math.random() * 6)}</b>`) });
add({ name: 'coin', cat: 'general', desc: 'coin flip', run: (c) => c.reply(`🪙 ${Math.random() < 0.5 ? 'HEADS' : 'TAILS'}`) });
add({ name: '8ball', alias: ['askfun'], cat: 'general', desc: 'magic 8ball', run: (c) => {
  const a = ['✅ হ্যাঁ', '❌ না', '🤔 সম্ভবত', '⏳ পরে চেষ্টা করুন', '✨ অবশ্যই'];
  return c.reply(`🎱 ${a[Math.floor(Math.random() * a.length)]}`);
} });
add({ name: 'rate', cat: 'general', desc: 'rate yourself', run: (c) => c.reply(`⭐ Rating: <b>${1 + Math.floor(Math.random() * 100)}%</b>`) });
add({ name: 'joke', cat: 'general', desc: 'মজার কথা', run: (c) => c.reply('😄 Bot কেন ঘুমায় না? কারণ তার সবসময় uptime থাকে!') });
add({ name: 'ship', cat: 'general', desc: 'দুজনের match', run: (c) => {
  const t = targets(c); if (t.length < 1) return c.reply(`কাউকে mention/reply করে ${c.prefix}ship লিখুন।`);
  return c.reply(`💞 Match score: <b>${1 + Math.floor(Math.random() * 100)}%</b>`);
} });

/* ───────── AI ───────── */
const aiLast = new Map();
add({ name: 'ai', alias: ['ask', 'gpt'], cat: 'ai', desc: 'AI-কে প্রশ্ন করুন', run: async (c) => {
  if (!c.q) return c.reply(`ব্যবহার: ${c.prefix}ai আপনার প্রশ্ন`);
  if (!config.aiKey) return c.reply('⚠️ AI কনফিগার করা নেই (AI_API_KEY).');
  if (Date.now() - (aiLast.get(c.jid) || 0) < 4000) return;
  aiLast.set(c.jid, Date.now());
  const res = await fetch(`${config.aiBase.replace(/\/$/, '')}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.aiKey}` },
    body: JSON.stringify({
      model: config.aiModel,
      temperature: 0.7,
      messages: [
        { role: 'system', content: 'You are a concise WhatsApp assistant. Reply in the same language as the user.' },
        { role: 'user', content: c.q }
      ]
    }),
    signal: AbortSignal.timeout(30_000)
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    if (res.status === 401) return c.reply('⚠️ AI API key ভুল/মেয়াদ শেষ। .env-এ নতুন AI_API_KEY দিন এবং বট restart করুন।');
    if (res.status === 402 || res.status === 429) return c.reply('⚠️ AI credit/quota শেষ বা rate limit হয়েছে। API account-এ billing/credits চেক করে কিছুক্ষণ পরে আবার চেষ্টা করুন।');
    if (res.status === 404) return c.reply(`⚠️ AI model বা API URL পাওয়া যায়নি। AI_BASE_URL=${config.aiBase}, AI_MODEL=${config.aiModel}`);
    return c.reply(`⚠️ AI error (${res.status})${body ? `: ${body.slice(0, 120)}` : ''}`);
  }
  const data = await res.json().catch(() => ({}));
  return c.reply('🤖 ' + (data?.choices?.[0]?.message?.content?.trim() || 'উত্তর পাওয়া যায়নি।'));
} });

/* ───────── TOOLS ───────── */
const run = (cmd, args) => new Promise((resolve, reject) => {
  const p = spawn(cmd, args, { stdio: 'ignore' }); // args array: no shell, no injection
  const t = setTimeout(() => p.kill('SIGKILL'), 30_000);
  p.on('error', (e) => { clearTimeout(t); reject(e); });
  p.on('close', (code) => { clearTimeout(t); code === 0 ? resolve() : reject(new Error('ffmpeg exit ' + code)); });
});

async function toWebp(buf, video) {
  const id = crypto.randomUUID();
  const inp = join(tmpdir(), `${id}.${video ? 'mp4' : 'jpg'}`);
  const out = join(tmpdir(), `${id}.webp`);
  await fs.writeFile(inp, buf);
  try {
    await run('ffmpeg', ['-y', '-i', inp, '-t', '6',
      '-vf', 'fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0,format=rgba',
      '-c:v', 'libwebp', '-lossless', '0', '-q:v', '50', '-loop', '0', '-an', out]);
    return await fs.readFile(out);
  } finally {
    await Promise.allSettled([fs.rm(inp, { force: true }), fs.rm(out, { force: true })]);
  }
}

add({ name: 'sticker', alias: ['s'], cat: 'tools', desc: 'ছবি/ভিডিও → স্টিকার (ffmpeg লাগে)', run: async (c) => {
  const own = unwrap(c.m.message);
  const ci = contextOf(c.m.message);
  const quoted = ci?.quotedMessage ? unwrap(ci.quotedMessage) : null;
  let target = null, media = null;
  if (own.imageMessage || own.videoMessage) { target = c.m; media = own.imageMessage || own.videoMessage; }
  else if (quoted?.imageMessage || quoted?.videoMessage) {
    media = quoted.imageMessage || quoted.videoMessage;
    target = { key: { remoteJid: c.jid, id: ci.stanzaId, participant: ci.participant, fromMe: false }, message: ci.quotedMessage };
  }
  if (!target) return c.reply(`ছবি/ভিডিওতে রিপ্লাই দিয়ে ${c.prefix}sticker লিখুন।`);
  const buf = await downloadMediaMessage(target, 'buffer', {}, { logger, reuploadRequest: c.sock.updateMediaMessage });
  let webp;
  try { webp = await toWebp(buf, !!own.videoMessage || !!quoted?.videoMessage); }
  catch (e) { return c.reply(e.code === 'ENOENT' ? '⚠️ সার্ভারে ffmpeg ইনস্টল নেই।' : '⚠️ স্টিকার বানানো যায়নি।'); }
  return c.sock.sendMessage(c.jid, { sticker: webp }, { quoted: c.m });
} });

const quotedMedia = (c) => {
  const own = unwrap(c.m.message);
  const ci = contextOf(c.m.message);
  const quoted = ci?.quotedMessage ? unwrap(ci.quotedMessage) : null;
  if (own.imageMessage || own.videoMessage || own.audioMessage || own.documentMessage) {
    return { message: c.m, value: own.imageMessage || own.videoMessage || own.audioMessage || own.documentMessage };
  }
  if (quoted?.imageMessage || quoted?.videoMessage || quoted?.audioMessage || quoted?.documentMessage) {
    return { message: { key: { remoteJid: ci.remoteJid || c.jid, id: ci.stanzaId, participant: ci.participant, fromMe: false }, message: ci.quotedMessage }, value: quoted.imageMessage || quoted.videoMessage || quoted.audioMessage || quoted.documentMessage };
  }
  return null;
};

add({ name: 'vv', alias: ['viewonce'], cat: 'tools', desc: 'send quoted media to your private DM', run: async (c) => {
  const media = quotedMedia(c);
  if (!media) return c.reply(`🎯 Reply to a photo or video with ${c.prefix}vv.`);
  const target = c.senderJids.find(Boolean) || c.jid;
  if (!target || target.endsWith('@g.us')) return c.reply('⚠️ I could not find your private chat.');
  const buf = await downloadMediaMessage(media.message, 'buffer', {}, { logger, reuploadRequest: c.sock.updateMediaMessage });
  const v = media.value;
  const payload = v.mimetype?.startsWith('video/') ? { video: buf, mimetype: v.mimetype, caption: '🎬 Your private media delivery • ARU BBZ' }
    : v.mimetype?.startsWith('audio/') ? { audio: buf, mimetype: v.mimetype, ptt: !!v.ptt }
      : v.mimetype?.startsWith('image/') ? { image: buf, mimetype: v.mimetype, caption: '🖼️ Your private media delivery • ARU BBZ' }
        : { document: buf, mimetype: v.mimetype || 'application/octet-stream', fileName: v.fileName || 'media.bin' };
  await c.sock.sendMessage(target, payload);
  return c.reply('✅ Delivered to your private DM. 🔐');
} });

add({ name: 'save', cat: 'tools', desc: 'save replied story media to your private DM', run: async (c) => {
  const media = quotedMedia(c);
  if (!media) return c.reply(`📥 Reply to a photo/video story with ${c.prefix}save.`);
  const target = c.senderJids.find(Boolean) || c.jid;
  if (!target || target.endsWith('@g.us')) return c.reply('⚠️ I could not find your private chat.');
  const buf = await downloadMediaMessage(media.message, 'buffer', {}, { logger, reuploadRequest: c.sock.updateMediaMessage });
  const v = media.value;
  const caption = '📥 Story saved successfully • ARU BBZ';
  const payload = v.mimetype?.startsWith('video/') ? { video: buf, mimetype: v.mimetype, caption }
    : v.mimetype?.startsWith('image/') ? { image: buf, mimetype: v.mimetype, caption }
      : v.mimetype?.startsWith('audio/') ? { audio: buf, mimetype: v.mimetype, ptt: !!v.ptt }
        : { document: buf, mimetype: v.mimetype || 'application/octet-stream', fileName: v.fileName || 'saved-story.bin', caption };
  await c.sock.sendMessage(target, payload);
  return c.reply('✅ Story saved to your private DM. 📥');
} });

/* ───────── GROUP ───────── */
add({ name: 'tagall', cat: 'group', desc: 'সবাইকে ট্যাগ', group: true, admin: true, run: (c) => {
  const ps = c.g.participants;
  const text = `📢 ${c.q || 'Attention!'}\n\n` + ps.map((p) => '▸ @' + num(p.id)).join('\n');
  return c.sock.sendMessage(c.jid, { text, mentions: ps.map((p) => p.id) }, { quoted: c.m });
} });

add({ name: 'hidetag', cat: 'group', desc: 'লুকানো ট্যাগ', group: true, admin: true, run: (c) => {
  const ci = contextOf(c.m.message);
  const text = c.q || unwrap(ci?.quotedMessage || {}).conversation || '\u200e';
  return c.sock.sendMessage(c.jid, { text, mentions: c.g.participants.map((p) => p.id) });
} });

const modify = (action, done) => async (c) => {
  const t = targets(c);
  if (!t.length) return c.reply(`কাউকে @mention বা রিপ্লাই করুন।`);
  await c.sock.groupParticipantsUpdate(c.jid, t, action);
  if (action === 'promote' || action === 'demote') {
    const actor = c.senderJids.find(Boolean) || `${c.senderNums[0]}@s.whatsapp.net`;
    const target = t[0];
    const verb = action === 'promote' ? 'PROMOTED' : 'DEMOTED';
    return c.sock.sendMessage(c.jid, {
      text: `╭─⊱ 🛡️ GROUP AUDIT ⊰─╮\n│ Group: ${c.g.subject}\n│ Action: ${verb}\n│ By: @${num(actor)}\n│ User: @${num(target)}\n╰────────────────────╯\n\n✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉`,
      mentions: [actor, target]
    }, { quoted: c.m });
  }
  return c.reply(done);
};
add({ name: 'kick', cat: 'group', desc: 'মেম্বার রিমুভ', group: true, admin: true, botAdmin: true, run: modify('remove', '✅ রিমুভ করা হয়েছে।') });
add({ name: 'promote', cat: 'group', desc: 'অ্যাডমিন বানান', group: true, admin: true, botAdmin: true, run: modify('promote', '✅ অ্যাডমিন করা হয়েছে।') });
add({ name: 'demote', cat: 'group', desc: 'অ্যাডমিন সরান', group: true, admin: true, botAdmin: true, run: modify('demote', '✅ অ্যাডমিন সরানো হয়েছে।') });

add({ name: 'mute', cat: 'group', desc: 'শুধু অ্যাডমিন মেসেজ দিতে পারবে', group: true, admin: true, botAdmin: true, run: async (c) => {
  await c.sock.groupSettingUpdate(c.jid, 'announcement'); return c.reply('🔇 গ্রুপ মিউট।');
} });
add({ name: 'unmute', cat: 'group', desc: 'সবাই মেসেজ দিতে পারবে', group: true, admin: true, botAdmin: true, run: async (c) => {
  await c.sock.groupSettingUpdate(c.jid, 'not_announcement'); return c.reply('🔊 গ্রুপ আনমিউট।');
} });

add({ name: 'link', cat: 'group', desc: 'গ্রুপ ইনভাইট লিংক', group: true, admin: true, botAdmin: true, run: async (c) =>
  c.reply('https://chat.whatsapp.com/' + await c.sock.groupInviteCode(c.jid)) });

add({ name: 'del', alias: ['delete'], cat: 'group', desc: 'রিপ্লাই করা মেসেজ ডিলিট', group: true, admin: true, botAdmin: true, run: async (c) => {
  const ci = contextOf(c.m.message);
  if (!ci?.stanzaId) return c.reply('যে মেসেজ ডিলিট করবেন তাতে রিপ্লাই দিন।');
  return c.sock.sendMessage(c.jid, { delete: { remoteJid: c.jid, fromMe: false, id: ci.stanzaId, participant: ci.participant } });
} });

add({ name: 'antilink', cat: 'group', desc: 'গ্রুপ-লিংক auto-delete (ডিফল্ট: on)', group: true, admin: true, botAdmin: true, run: (c) => toggle(c, 'antilink') });
add({ name: 'antispam', cat: 'group', desc: 'বেশি মেসেজ দিলে auto-kick (ডিফল্ট: on)', group: true, admin: true, botAdmin: true, run: (c) => toggle(c, 'antispam') });
for (const key of ['antisticker', 'antiforward', 'antigroupstatus', 'antibot', 'antiaudio', 'antivideo', 'antidoc', 'antiimage', 'antilocation', 'antipoll', 'antivoice', 'antivv', 'antiword', 'antitag', 'anticontact']) {
  add({ name: key, cat: 'group', desc: `${key} protection`, group: true, admin: true, botAdmin: true, run: (c) => toggle(c, key) });
}
add({ name: 'welcome', cat: 'group', desc: 'ভিডিওসহ স্বাগতম মেসেজ (ডিফল্ট: on)', group: true, admin: true, run: (c) => toggle(c, 'welcome') });
add({ name: 'goodbye', cat: 'group', desc: 'ভিডিওসহ goodbye মেসেজ (ডিফল্ট: on)', group: true, admin: true, run: (c) => toggle(c, 'goodbye') });

add({ name: 'groupinfo', cat: 'group', desc: 'গ্রুপের তথ্য', group: true, run: (c) => {
  const admins = c.g.participants.filter((p) => p.admin).length;
  return c.reply(`👥 ${c.g.subject}\n🧑 মেম্বার: ${c.g.participants.length}\n🛡️ অ্যাডমিন: ${admins}\n${c.g.desc ? '\n' + c.g.desc : ''}`);
} });

add({ name: 'ginfo', alias: ['settings'], cat: 'group', desc: 'গ্রুপ info/settings', group: true, run: (c) => {
  const admins = c.g.participants.filter((p) => p.admin).length;
  return c.reply(`╭─⊱ 👥 GROUP INFO ⊰─╮\n│ নাম: ${c.g.subject}\n│ মেম্বার: ${c.g.participants.length}\n│ অ্যাডমিন: ${admins}\n│ antilink: ${c.s.antilink[c.jid] !== false ? 'ON' : 'OFF'}\n│ antispam: ${c.s.antispam[c.jid] !== false ? 'ON' : 'OFF'}\n│ welcome: ${c.s.welcome[c.jid] !== false ? 'ON' : 'OFF'}\n╰────────────────────╯`);
} });

add({ name: 'gstatus', cat: 'group', desc: 'post a replied message to group status', group: true, admin: true, run: async (c) => {
  const ci = contextOf(c.m.message);
  if (!ci?.quotedMessage) return c.reply(`📲 Reply to a message with ${c.prefix}gstatus.`);
  const quoted = unwrap(ci.quotedMessage);
  const members = c.g.participants.map((p) => p.phoneNumber || p.id).filter((jid) => jid && jid.includes('@'));
  const media = quoted.imageMessage || quoted.videoMessage || quoted.audioMessage || quoted.documentMessage;
  let payload;
  if (media) {
    const target = { key: { remoteJid: ci.remoteJid || c.jid, id: ci.stanzaId, participant: ci.participant, fromMe: false }, message: ci.quotedMessage };
    const buf = await downloadMediaMessage(target, 'buffer', {}, { logger, reuploadRequest: c.sock.updateMediaMessage });
    if (media.mimetype?.startsWith('video/')) payload = { video: buf, mimetype: media.mimetype, caption: media.caption || '📢 Group status • ARU BBZ' };
    else if (media.mimetype?.startsWith('image/')) payload = { image: buf, mimetype: media.mimetype, caption: media.caption || '📢 Group status • ARU BBZ' };
    else if (media.mimetype?.startsWith('audio/')) payload = { audio: buf, mimetype: media.mimetype, ptt: !!media.ptt };
    else payload = { document: buf, mimetype: media.mimetype || 'application/octet-stream', fileName: media.fileName || 'group-status.bin' };
  } else {
    const text = quoted.conversation || quoted.extendedTextMessage?.text || quoted.imageMessage?.caption || c.q;
    if (!text) return c.reply('⚠️ The replied message has no supported text or media.');
    payload = { text: `📢 ${text}\n\n✦ Powered By 𝙰𝚁𝚄 𝙱𝙱𝚉` };
  }
  await c.sock.sendMessage('status@broadcast', payload, { statusJidList: members });
  return c.reply('✅ Posted to the group status. 📲');
} });

add({ name: 'all', alias: ['tag'], cat: 'group', desc: 'সবাইকে ট্যাগ', group: true, admin: true, run: (c) => {
  const ps = c.g.participants;
  return c.sock.sendMessage(c.jid, { text: `📢 ${c.q || 'Attention'}\n\n${ps.map((p) => '⊹ @' + num(p.id)).join('\n')}`, mentions: ps.map((p) => p.id) }, { quoted: c.m });
} });

add({ name: 'add', cat: 'group', desc: 'মেম্বার যোগ', group: true, admin: true, botAdmin: true, run: async (c) => {
  const n = (c.args[0] || '').replace(/\D/g, '');
  if (!/^\d{8,15}$/.test(n)) return c.reply(`ব্যবহার: ${c.prefix}add 8801XXXXXXXXX`);
  await c.sock.groupParticipantsUpdate(c.jid, [`${n}@s.whatsapp.net`], 'add');
  return c.reply('✅ যোগ করার অনুরোধ পাঠানো হয়েছে। privacy policy অনুযায়ী invite লাগতে পারে।');
} });

add({ name: 'warn', cat: 'group', desc: 'warning দিন', group: true, admin: true, run: (c) => {
  const t = targets(c)[0];
  if (!t) return c.reply(`কাউকে reply/mention করে ${c.prefix}warn দিন।`);
  const n = num(t); c.s.warnings[n] = (c.s.warnings[n] || 0) + 1; saveSettings(c.id);
  const limit = c.s.warningLimit === 'unlimited' ? '∞' : c.s.warningLimit;
  return c.sock.sendMessage(c.jid, { text: `⚠️ @${n}-কে warning ${c.s.warnings[n]}/${limit}`, mentions: [t] }, { quoted: c.m });
} });

add({ name: 'warnlimit', cat: 'group', desc: 'set warning threshold', group: true, admin: true, run: (c) => {
  const value = (c.args[0] || '').toLowerCase();
  if (value !== 'unlimited' && !/^(3|5|7|15|20|30|50|100|1000)$/.test(value)) {
    return c.reply(`Usage: ${c.prefix}warnlimit 3|5|7|15|20|30|50|100|1000|unlimited\nCurrent: ${c.s.warningLimit}`);
  }
  c.s.warningLimit = value === 'unlimited' ? 'unlimited' : Number(value); saveSettings(c.id);
  return c.reply(`✅ Warning limit set to: ${c.s.warningLimit === 'unlimited' ? 'unlimited' : c.s.warningLimit}`);
} });

add({ name: 'warns', cat: 'group', desc: 'warnings দেখুন', group: true, run: (c) => {
  const rows = Object.entries(c.s.warnings).filter(([, n]) => n > 0).map(([n, v]) => `⊹ @${n}: ${v}`);
  return c.reply(rows.length ? `⚠️ WARNINGS\n${rows.join('\n')}` : '✅ কোনো warning নেই।');
} });

add({ name: 'resetwarn', cat: 'group', desc: 'warnings reset', group: true, admin: true, run: (c) => {
  const t = targets(c)[0];
  if (!t) return c.reply(`কাউকে reply/mention করে ${c.prefix}resetwarn দিন।`);
  delete c.s.warnings[num(t)]; saveSettings(c.id); return c.reply('✅ warning reset হয়েছে।');
} });

/* ───────── OWNER ───────── */
add({ name: 'mode', cat: 'owner', desc: 'self/public', owner: true, run: (c) => {
  const v = (c.args[0] || '').toLowerCase();
  if (!['self', 'public'].includes(v)) return c.reply(`ব্যবহার: ${c.prefix}mode self|public\nএখন: ${c.s.mode}`);
  c.s.mode = v; saveSettings(c.id);
  return c.reply(`✅ mode: ${v}`);
} });

add({ name: 'prefix', cat: 'owner', desc: 'প্রিফিক্স বদলান', owner: true, run: (c) => {
  const v = c.args[0];
  if (!v || v.length > 3) return c.reply(`ব্যবহার: ${c.prefix}prefix !  (১–৩ অক্ষর)`);
  c.s.prefix = v; saveSettings(c.id);
  return c.reply(`✅ নতুন প্রিফিক্স: ${v}`);
} });

add({ name: 'sudo', cat: 'owner', desc: 'sudo add|del|list', owner: true, run: (c) => {
  const [act, arg] = [(c.args[0] || '').toLowerCase(), c.args[1]];
  if (act === 'list') return c.reply(c.s.sudo.length ? c.s.sudo.map((n) => '▸ ' + n).join('\n') : 'কোনো sudo নেই।');
  const n = arg ? arg.replace(/\D/g, '') : targets(c).map(num)[0];
  if (!['add', 'del'].includes(act) || !n) return c.reply(`ব্যবহার: ${c.prefix}sudo add|del <নম্বর/@mention>`);
  c.s.sudo = act === 'add' ? [...new Set([...c.s.sudo, n])] : c.s.sudo.filter((x) => x !== n);
  saveSettings(c.id);
  return c.reply(`✅ sudo ${act}: ${n}`);
} });

/* registry: name + aliases -> command */
export const commands = new Map();
for (const def of list) {
  commands.set(def.name, def);
  for (const a of def.alias || []) commands.set(a, def);
}
