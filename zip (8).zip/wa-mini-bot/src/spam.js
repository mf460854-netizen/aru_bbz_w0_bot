// In-memory anti-spam tracker: resets on restart, which is fine for a
// "many messages in a few seconds" flood check. Nothing is written to disk.
const WINDOW_MS = 10_000;
const LIMIT = 7; // messages allowed inside the window before it's a flood

const hits = new Map(); // `${groupJid}:${senderNum}` -> timestamps[]

export function registerAndCheck(groupJid, senderNum) {
  const key = `${groupJid}:${senderNum}`;
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < WINDOW_MS);
  arr.push(now);
  hits.set(key, arr);
  return arr.length > LIMIT;
}

export function clear(groupJid, senderNum) {
  hits.delete(`${groupJid}:${senderNum}`);
}
