import { getSettings, saveSettings } from './store.js';
import { commands } from './commands.js';
import { config } from './config.js';
import * as spam from './spam.js';
import { num, idsOf, unwrap, tsOf } from './util.js';
import { welcomeMessage, goodbyeMessage, brandFooter } from './welcome.js';

const LINK_RE = /chat\.whatsapp\.com\/[A-Za-z0-9]{10,}/i;

// antilink / antispam / welcome default to ON; a group only turns them off
// by explicitly running `.antilink off` etc. (toggle() in commands.js stores
// an explicit true/false, so "unset" always means "on").
const DEFAULT_ON = new Set(['antilink', 'antispam', 'welcome', 'goodbye']);
const on = (map, jid, key) => map[jid] === true || (map[jid] === undefined && DEFAULT_ON.has(key));
const reactionFor = (cmd) => ({
  menu: '📚', help: '📚', ping: '🏓', alive: '🟢', owner: '👑', channel: '📢',
  ai: '🤖', ask: '🤖', gpt: '🤖', dice: '🎲', coin: '🪙', joke: '😄',
  sticker: '✨', vv: '📥', save: '💾', tagall: '📣', hidetag: '📣', promote: '🛡️', demote: '🛡️',
  kick: '🚫', warn: '⚠️', add: '➕', link: '🔗'
}[cmd.name] || ({ general: '✅', ai: '🤖', tools: '🛠️', group: '🛡️', owner: '👑' }[cmd.cat] || '✅'));

export async function handleMessage(sock, m, id) {
  const jid = m.key?.remoteJid;
  if (!m.message || !jid) return;
  if (jid === 'status@broadcast' || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;

  const ts = tsOf(m.messageTimestamp);
  if (ts && Date.now() / 1000 - ts > 30) return; // ignore history / old messages

  const msg = unwrap(m.message);
  const isViewOnce = !!(m.message.viewOnceMessage || m.message.viewOnceMessageV2);
  const text = (msg.conversation || msg.extendedTextMessage?.text ||
    msg.imageMessage?.caption || msg.videoMessage?.caption || '').trim();
  const s = getSettings(id);
  const isGroup = jid.endsWith('@g.us');
  const fromMe = !!m.key.fromMe;
  const senderJids = fromMe
    ? [sock.user?.id, sock.user?.lid]
    : [m.key.participant, m.key.participantAlt, m.key.remoteJidAlt, isGroup ? null : jid];
  const senderNums = senderJids.filter(Boolean).map(num);
  // the bot's global owner number always has owner rights here, on every paired
  // session, even when that session's own mode is "self" (private).
  const owner = fromMe
    || (s.phone && senderNums.includes(s.phone))
    || s.sudo.some((n) => senderNums.includes(n))
    || (config.ownerNumber && senderNums.includes(config.ownerNumber))
    || (config.owner2Number && senderNums.includes(config.owner2Number));
  const botNums = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ctxInfo = Object.values(msg).find((v) => v && typeof v === 'object' && v.contextInfo)?.contextInfo;
  const kind = isViewOnce ? 'antivv'
    : msg.stickerMessage ? 'antisticker'
    : msg.audioMessage?.ptt ? 'antivoice'
    : msg.audioMessage ? 'antiaudio'
    : msg.videoMessage ? 'antivideo'
    : msg.documentMessage ? 'antidoc'
    : msg.imageMessage ? 'antiimage'
    : msg.locationMessage || msg.liveLocationMessage ? 'antilocation'
    : msg.pollCreationMessage || msg.pollUpdateMessage ? 'antipoll'
    : msg.contactMessage || msg.contactsArrayMessage ? 'anticontact'
    : ctxInfo?.isForwarded || Number(ctxInfo?.forwardingScore) > 0 ? 'antiforward'
    : Array.isArray(ctxInfo?.mentionedJid) && ctxInfo.mentionedJid.length ? 'antitag'
    : /^[.!#][a-z0-9]/i.test(text) ? 'antibot'
    : config.antiWords.some((word) => word && text.toLowerCase().includes(word.toLowerCase())) ? 'antiword'
    : null;

  const reply = (t, extra = {}) => {
    const raw = String(t);
    const text = raw.startsWith('╭')
      ? raw
      : `╭─⊱ ✦ ${config.botName} ✦ ⊰─╮\n│ ✨ ${raw}\n╰───────────────────╯\n${brandFooter}`;
    return sock.sendMessage(jid, { text, ...extra }, { quoted: m });
  };

  // anti-link + anti-spam only apply to ordinary (non-admin, non-owner) members
  const antiKeys = ['antilink', 'antispam', 'antisticker', 'antiforward', 'antigroupstatus', 'antibot', 'antiaudio', 'antivideo', 'antidoc', 'antiimage', 'antilocation', 'antipoll', 'antivoice', 'antivv', 'antiword', 'antitag', 'anticontact'];
  const antiEnabled = antiKeys.some((key) => on(s[key], jid, key));
  if (isGroup && !fromMe && !owner && antiEnabled) {
    const g = await sock.getGroup(jid).catch(() => null);
    const sp = g?.participants.find((p) => idsOf(p).some((x) => senderNums.includes(x)));
    const isBotAdminHere = !!g?.participants.find((p) => idsOf(p).some((x) => botNums.includes(x)))?.admin;

    if (!sp?.admin) {
      if (on(s.antilink, jid, 'antilink') && LINK_RE.test(text)) {
        const action = s.antiActions.antilink || 'delete';
        if (action === 'kick' && isBotAdminHere) await sock.groupParticipantsUpdate(jid, [senderJids[0] || `${senderNums[0]}@s.whatsapp.net`], 'remove').catch(() => {});
        else if (action === 'warn') { const n = senderNums[0] || 'user'; s.warnings[n] = (s.warnings[n] || 0) + 1; saveSettings(id); await sock.sendMessage(jid, { text: `⚠️ @${n} warning ${s.warnings[n]}/${s.warningLimit}`, mentions: senderJids.filter(Boolean) }).catch(() => {}); }
        else await sock.sendMessage(jid, { delete: m.key }).catch(() => {});
        return; // message removed, nothing else to do with it
      }
      if (kind && on(s[kind], jid, kind)) {
        const action = s.antiActions[kind] || 'delete';
        if (action === 'kick' && isBotAdminHere) await sock.groupParticipantsUpdate(jid, [senderJids[0] || `${senderNums[0]}@s.whatsapp.net`], 'remove').catch(() => {});
        else if (action === 'warn') { const n = senderNums[0] || 'user'; s.warnings[n] = (s.warnings[n] || 0) + 1; saveSettings(id); await sock.sendMessage(jid, { text: `⚠️ @${n} warning ${s.warnings[n]}/${s.warningLimit}`, mentions: senderJids.filter(Boolean) }).catch(() => {}); }
        else await sock.sendMessage(jid, { delete: m.key }).catch(() => {});
        return;
      }
      if (on(s.antispam, jid, 'antispam') && spam.registerAndCheck(jid, senderNums[0])) {
        spam.clear(jid, senderNums[0]);
        if (isBotAdminHere) {
          await sock.groupParticipantsUpdate(jid, [senderJids[0] || senderNums[0] + '@s.whatsapp.net'], 'remove').catch(() => {});
          await sock.sendMessage(jid, { text: `🚫 স্প্যামের জন্য @${senderNums[0]} রিমুভ করা হলো।`, mentions: [senderJids[0]] }).catch(() => {});
        }
        return;
      }
    }
  }

  if (!text || !text.startsWith(s.prefix)) return;
  const [raw, ...args] = text.slice(s.prefix.length).trim().split(/\s+/);
  const cmd = commands.get((raw || '').toLowerCase());
  if (!cmd) return;
  if (s.mode === 'self' && !owner) return;
  if (cmd.owner && !owner) return reply('🔒 শুধু owner এই কমান্ড চালাতে পারবে।');
  if (cmd.group && !isGroup) return reply('👥 এটা শুধু গ্রুপে চলে।');

  let g = null, isAdmin = !!owner, isBotAdmin = false;
  if (isGroup && (cmd.group || cmd.admin || cmd.botAdmin)) {
    g = await sock.getGroup(jid).catch(() => null);
    if (!g) return reply('⚠️ গ্রুপের তথ্য আনা যায়নি, আবার চেষ্টা করুন।');
    const sp = g.participants.find((p) => idsOf(p).some((x) => senderNums.includes(x)));
    isAdmin = owner || !!sp?.admin;
    isBotAdmin = !!g.participants.find((p) => idsOf(p).some((x) => botNums.includes(x)))?.admin;
  }
  if (cmd.admin && !isAdmin) return reply('🛡️ শুধু গ্রুপ অ্যাডমিন।');
  if (cmd.botAdmin && !isBotAdmin) return reply('🤖 আগে বটকে গ্রুপ অ্যাডমিন বানান।');

  const ctx = {
    sock, m, id, jid, s, g, isGroup, owner, isAdmin, isBotAdmin, senderJids, senderNums,
    prefix: s.prefix, args, q: args.join(' '), text, reply,
    msgTime: ts * 1000
  };
  try {
    await sock.sendMessage(jid, { react: { text: reactionFor(cmd), key: m.key } }).catch(() => {});
    await cmd.run(ctx);
  } catch (e) {
    console.error(`[cmd:${cmd.name}]`, e.message);
    reply('⚠️ কমান্ডে সমস্যা হয়েছে: ' + (e.message || 'unknown').slice(0, 120)).catch(() => {});
  }
}

export async function handleParticipants(sock, ev, id) {
  const s = getSettings(id);
  if (ev.action === 'remove') {
    if (on(s.goodbye, ev.id, 'goodbye')) {
      const g = await sock.getGroup(ev.id).catch(() => null);
      const payload = await goodbyeMessage({ groupName: g?.subject || 'this group', mentions: ev.participants, memberCount: g?.participants?.length || 0 });
      await sock.sendMessage(ev.id, payload).catch((e) => console.error('[goodbye]', e.message));
    }
    return;
  }
  if (ev.action !== 'add' || !on(s.welcome, ev.id, 'welcome')) return;
  const ps = ev.participants.map((p) => (typeof p === 'string' ? { id: p } : p));
  const mentions = ps.map((p) => p.id);
  const g = await sock.getGroup(ev.id).catch(() => null);
  const payload = await welcomeMessage({ groupName: g?.subject || 'this group', mentions, memberCount: g?.participants?.length || 0 });
  await sock.sendMessage(ev.id, payload).catch((e) => console.error('[welcome]', e.message));
}
