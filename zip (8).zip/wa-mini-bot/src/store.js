import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

const dir = path.join(config.dataDir, 'settings');
const cache = new Map();
const timers = new Map();

const defaults = () => ({
  prefix: config.prefix,
  mode: 'self', // self = only the owner can use commands
  phone: '',
  sudo: [],
  antilink: {},
  antispam: {},
  antisticker: {},
  antiforward: {},
  antigroupstatus: {},
  antibot: {},
  antiaudio: {},
  antivideo: {},
  antidoc: {},
  antiimage: {},
  antilocation: {},
  antipoll: {},
  antivoice: {},
  antivv: {},
  antiword: {},
  antitag: {},
  anticontact: {},
  welcome: {},
  goodbye: {},
  warnings: {},
  warningLimit: 3,
  antiActions: {}
});

export function getSettings(id) {
  id = String(id);
  let s = cache.get(id);
  if (!s) {
    let disk = {};
    try { disk = JSON.parse(fs.readFileSync(path.join(dir, `${id}.json`), 'utf8')); } catch {}
    s = { ...defaults(), ...disk };
    if (!/^[!#$%&*+\-./:;<=>?@[\]^_{|}~]$/.test(s.prefix || '')) s.prefix = config.prefix;
    cache.set(id, s);
  }
  return s;
}

// debounced write so heavy command bursts don't hit the disk
export function saveSettings(id) {
  id = String(id);
  clearTimeout(timers.get(id));
  timers.set(id, setTimeout(() => {
    const s = cache.get(id);
    if (!s) return;
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, `${id}.json`), JSON.stringify(s));
    } catch (e) { console.error('[store] save failed:', e.message); }
  }, 500));
}

export function dropSettings(id) {
  id = String(id);
  clearTimeout(timers.get(id));
  timers.delete(id);
  cache.delete(id);
  try { fs.rmSync(path.join(dir, `${id}.json`), { force: true }); } catch {}
}
